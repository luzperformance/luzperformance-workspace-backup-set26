#!/usr/bin/env bash
exec /data/Luzperformance/leads-novos/run_check.sh
