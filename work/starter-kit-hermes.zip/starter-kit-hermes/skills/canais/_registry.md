# Skills: canais

- `wizard-whatsapp`
