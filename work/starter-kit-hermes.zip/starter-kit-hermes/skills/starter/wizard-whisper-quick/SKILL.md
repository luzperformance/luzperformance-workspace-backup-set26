---
name: wizard-whisper-quick
description: "Use quando configurar transcrição de voz no Hermes."
version: 3.0.0
author: Starter Kit Hermes PT-BR
license: MIT
metadata:
  hermes:
    tags: [starter-kit, pt-br]
---

# wizard-whisper-quick

Prefira configuração nativa de STT:
```bash
hermes config set stt.enabled true
hermes config set stt.provider local
```
Para local, instale `faster-whisper` apenas se ausente e com autorização. Alternativas: Groq, OpenAI, Mistral, ElevenLabs e DeepInfra. Segredos vão ao ambiente oficial. Valide com uma mensagem de voz real; não declare sucesso apenas porque a configuração foi salva.
