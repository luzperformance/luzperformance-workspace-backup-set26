#!/usr/bin/env bash
exec python3 /data/Luzperformance/leads-novos/monitor_leads.py check
