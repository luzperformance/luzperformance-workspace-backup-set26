# MAPA — Luzperformance/

> Área operacional da Luz Performance para ativos de negócio que não pertencem ao sistema interno do Hermes.

## Estrutura

- `DR LUIZ/` — ativos e materiais do projeto Dr. Luiz.
- `leads-novos/` — automações, validações e materiais do fluxo de novos leads.
- `Agenda-geral/` — materiais e referências de apoio à agenda geral.

## Regra

Cada frente relevante mantém o próprio `MAPA.md`. Não colocar rascunhos editoriais aqui: eles vivem em `content/`.
