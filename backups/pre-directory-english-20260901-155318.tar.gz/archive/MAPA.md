# MAPA — archive/

> Histórico recuperável de arquivos substituídos. Não é lixeira.

## Uso

- Guardar versões antigas antes de uma substituição relevante.
- Nomear como `{nome-original}-{YYYY-MM-DD}.{ext}`.
- Para conteúdo publicado, preferir `content/archive/`, que preserva o contexto editorial.

## Não usar para

- Lixo ou arquivos quebrados: usar a lixeira do sistema.
- Backups automáticos: usar `backups/`.
